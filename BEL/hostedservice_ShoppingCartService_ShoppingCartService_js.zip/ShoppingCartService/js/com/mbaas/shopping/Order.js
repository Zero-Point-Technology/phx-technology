
function Order()
{
  
  this.items = null;
  
  this.objectId = null;
  
  this.orderPrice = null;
  
}
  