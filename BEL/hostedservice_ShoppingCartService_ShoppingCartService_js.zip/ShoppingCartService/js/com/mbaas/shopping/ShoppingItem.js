
function ShoppingItem()
{
  
  this.objectId = null;
  
  this.product = null;
  
  this.price = null;
  
  this.quantity = null;
  
}
  